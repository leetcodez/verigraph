# Raft Consensus

## Leader Election
Raft elects a Leader using randomized election timeouts.

## Split-Brain Mitigation
Raft strictly prevents Split-Brain by requiring a Majority Quorum for all state transitions.